<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">Код</th>
                    <th scope="col">Наименование</th>
                    <th scope="col">Уровень1</th>
                    <th scope="col">Уровень2</th>
                    <th scope="col">Уровень3</th>
                    <th scope="col">Цена</th>
                    <th scope="col">ЦенаСП</th>
                    <th scope="col">Количество</th>
                    <th scope="col">Поля свойств</th>
                    <th scope="col">Совместные покупки</th>
                    <th scope="col">Единица измерения</th>
                    <th scope="col">Картинка</th>
                    <th scope="col">Выводить на главной</th>
                    <th scope="col">Описание</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item['code']); ?></td>
                        <td><?php echo e($item['title']); ?></td>
                        <td><?php echo e($item['level1']); ?></td>
                        <td><?php echo e($item['level2']); ?></td>
                        <td><?php echo e($item['level3']); ?></td>
                        <td><?php echo e($item['price']); ?></td>
                        <td><?php echo e($item['price_sp']); ?></td>
                        <td><?php echo e($item['count']); ?></td>
                        <td><?php echo e($item['properties']); ?></td>
                        <td><?php echo e($item['joint_purchases']); ?></td>
                        <td><?php echo e($item['unit']); ?></td>
                        <td><?php echo e($item['picture']); ?></td>
                        <td><?php echo e($item['show_on_home']); ?></td>
                        <td><?php echo e($item['description']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo e($items->links('pagination::bootstrap-4')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel.loc\resources\views/site/show.blade.php ENDPATH**/ ?>